package com.dianerverotect;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.appbar.MaterialToolbar;
import android.view.Gravity;

import com.dianerverotect.chatbot.ChatAdapter;
import com.dianerverotect.chatbot.ChatMessage;
import com.dianerverotect.chatbot.DialogflowService;
import com.dianerverotect.chatbot.MedicalAIModel;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.dianerverotect.chatbot.QuestionnaireMedicalFragment;
import com.dianerverotect.chatbot.ChatbotHistoryFragment;
import androidx.fragment.app.DialogFragment;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;

public class ChatbotFragment extends Fragment {

    private static final String TAG = "ChatbotFragment";
    
    // UI Components
    private RecyclerView chatRecyclerView;
    private EditText messageInput;
    private ImageButton sendButton;
    
    // Chat messages
    private List<ChatMessage> chatMessages;
    private ChatAdapter chatAdapter;
    
    // Medical AI model for handling predictions
    private MedicalAIModel medicalAIModel;
    
    // Dialogflow service for natural language processing
    private DialogflowService dialogflowService;

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private MaterialToolbar toolbar;

    private static final String PREFS_HISTORY = "chatbot_history";
    private static final String KEY_HISTORY = "history_json";
    private static final int MAX_HISTORY = 50;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chatbot, container, false);
        
        // Drawer et NavigationView
        drawerLayout = view.findViewById(R.id.drawer_layout);
        navigationView = view.findViewById(R.id.navigation_view);
        toolbar = view.findViewById(R.id.toolbar);

        // Icône hamburger ouvre le Drawer
        toolbar.setNavigationOnClickListener(v -> drawerLayout.openDrawer(Gravity.START));

        // Gestion des clics sur le menu latéral
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_questionnaire) {
                DialogFragment dialog = new QuestionnaireMedicalFragment();
                dialog.show(requireActivity().getSupportFragmentManager(), "QuestionnaireDialog");
                drawerLayout.closeDrawers();
                return true;
            } else if (id == R.id.nav_history) {
                DialogFragment dialog = new ChatbotHistoryFragment();
                dialog.show(requireActivity().getSupportFragmentManager(), "HistoryDialog");
                drawerLayout.closeDrawers();
                return true;
            } else if (id == R.id.nav_about) {
                // Dialogue professionnel "À propos du chatbot"
                LinearLayout layout = new LinearLayout(getContext());
                layout.setOrientation(LinearLayout.VERTICAL);
                layout.setPadding(48, 32, 48, 32);
                layout.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
                layout.setBackgroundResource(R.drawable.rounded_card_background);

                ImageView logo = new ImageView(getContext());
                logo.setImageResource(R.drawable.logo_app);
                LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(140, 140);
                logoParams.bottomMargin = 24;
                logo.setLayoutParams(logoParams);
                layout.addView(logo);

                TextView title = new TextView(getContext());
                title.setText("🤖 À propos du chatbot médical");
                title.setTextSize(22);
                title.setTypeface(null, android.graphics.Typeface.BOLD);
                title.setTextColor(getResources().getColor(R.color.aubergine));
                title.setPadding(0, 0, 0, 18);
                layout.addView(title);

                TextView message = new TextView(getContext());
                message.setText(
                    "Notre application embarque un chatbot intelligent conçu pour faciliter la détection précoce de certaines maladies neurologiques, en particulier la neuropathie périphérique et la sclérose latérale amyotrophique (SLA).\n\n"
                    + "🔬 Grâce à une série de questions simples mais cliniquement ciblées, ce chatbot :\n\n"
                    + "📋 Collecte les symptômes sensoriels, moteurs et autonomes ressentis par le patient\n\n"
                    + "🧠 Utilise deux modèles d'intelligence artificielle pour analyser les réponses et prédire l'orientation vers une neuropathie ou une SLA\n\n"
                    + "📄 Génère un rapport synthétique que le patient peut présenter à un professionnel de santé\n\n"
                    + "📈 Permet un suivi dans le temps en cas de réévaluation des symptômes\n\n"
                    + "\n⚠️ Ce chatbot ne remplace pas un diagnostic médical. Il est conçu comme un outil d'aide à la décision et d'orientation préclinique.\n\n"
                    + "💻 Développé par l'équipe projet :\n\n"
                    + "Benaboud Roqia\n"
                    + "Zouaoui Sirine\n"
                    + "Chebout Ibrahim Rassim\n"
                    + "Lameri Lokmane\n\n"
                    + "🧑‍🏫 Encadré par :\n\n"
                    + "Dr. Dehimi Nour El Houda\n"
                    + "Dr. Tolba Zakaria\n\n"
                    + "📬 Contactez-nous\n\n"
                    + "Pour toute suggestion, question ou collaboration, n'hésitez pas à nous contacter :\n\n"
                    + "📧 Email : benaboud.roqia@univ-oeb.dz et zououi.sirine@univ-oeb.dz"
                );
                message.setTextSize(16);
                message.setTextColor(0xFF333333);
                message.setPadding(0, 0, 0, 12);
                layout.addView(message);

                // Ajout des numéros de téléphone cliquables
                TextView phoneNumbers = new TextView(getContext());
                phoneNumbers.setText("Téléphone :\nRoqia : 0796446383\nSirine : 0659415646\nRassim : 0657162706\nLokmane : 0676313198");
                phoneNumbers.setTextSize(16);
                phoneNumbers.setTextColor(getResources().getColor(R.color.aubergine_light));
                phoneNumbers.setPadding(0, 16, 0, 0);
                phoneNumbers.setAutoLinkMask(0);
                phoneNumbers.setLinksClickable(true);
                phoneNumbers.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
                String text = phoneNumbers.getText().toString();
                android.text.SpannableString spannable = new android.text.SpannableString(text);
                int startRoqia = text.indexOf("0796446383");
                int endRoqia = startRoqia + "0796446383".length();
                spannable.setSpan(new android.text.style.ClickableSpan() {
                    @Override
                    public void onClick(View widget) {
                        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:0796446383"));
                        startActivity(intent);
                    }
                }, startRoqia, endRoqia, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                int startSirine = text.indexOf("0659415646");
                int endSirine = startSirine + "0659415646".length();
                spannable.setSpan(new android.text.style.ClickableSpan() {
                    @Override
                    public void onClick(View widget) {
                        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:0659415646"));
                        startActivity(intent);
                    }
                }, startSirine, endSirine, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                int startRassim = text.indexOf("0657162706");
                int endRassim = startRassim + "0657162706".length();
                spannable.setSpan(new android.text.style.ClickableSpan() {
                    @Override
                    public void onClick(View widget) {
                        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:0657162706"));
                        startActivity(intent);
                    }
                }, startRassim, endRassim, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                int startLokmane = text.indexOf("0676313198");
                int endLokmane = startLokmane + "0676313198".length();
                spannable.setSpan(new android.text.style.ClickableSpan() {
                    @Override
                    public void onClick(View widget) {
                        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:0676313198"));
                        startActivity(intent);
                    }
                }, startLokmane, endLokmane, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                phoneNumbers.setText(spannable);
                layout.addView(phoneNumbers);

                ScrollView scrollView = new ScrollView(getContext());
                scrollView.addView(layout);

                new AlertDialog.Builder(getContext())
                        .setView(scrollView)
                        .setPositiveButton("Fermer", null)
                        .setNegativeButton("Contacter", (dialog, which) -> {
                            Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                            emailIntent.setData(Uri.parse("mailto:benaboud.roqia@univ-oeb.dz, zououi.sirine@univ-oeb.dz"));
                            emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Contact - Chatbot médical");
                            startActivity(Intent.createChooser(emailIntent, "Envoyer un email"));
                        })
                        .show();
                drawerLayout.closeDrawers();
                return true;
            }
            return false;
        });
        
        // Initialize UI components
        chatRecyclerView = view.findViewById(R.id.chat_recycler_view);
        messageInput = view.findViewById(R.id.message_input);
        sendButton = view.findViewById(R.id.send_button_fab);
        
        // Initialize chat messages and adapter
        chatMessages = new ArrayList<>();
        chatAdapter = new ChatAdapter(getContext(), chatMessages);
        
        // Set up RecyclerView with improved scrolling
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setStackFromEnd(true);
        chatRecyclerView.setLayoutManager(layoutManager);
        chatRecyclerView.setAdapter(chatAdapter);
        chatRecyclerView.setHasFixedSize(false);
        chatRecyclerView.setItemAnimator(new DefaultItemAnimator());
        
        // Initialize Medical AI Model
        medicalAIModel = new MedicalAIModel(getContext());
        boolean modelsLoaded = medicalAIModel.initialize();
        
        if (!modelsLoaded) {
            Log.e(TAG, "Error loading AI models");
            Toast.makeText(getContext(), "Error loading AI models", Toast.LENGTH_SHORT).show();
        } else {
            Log.d(TAG, "AI models loaded successfully");
        }
        
        // Initialize Dialogflow Service
        dialogflowService = new DialogflowService(getContext());
        dialogflowService.initialize();
        
        // Add welcome message
        addBotMessage("Hello! I'm NerveBot, your medical assistant for neuropathy and ALS. How can I help you today?");
        
        // Set up send button click listener
        sendButton.setOnClickListener(v -> {
            String message = messageInput.getText().toString().trim();
            if (!message.isEmpty()) {
                sendMessage(message);
                messageInput.setText("");
            }
        });
        
        return view;
    }
    
    private void sendMessage(String message) {
        // Add user message to chat
        addUserMessage(message);
        
        // Identify language
        LanguageIdentifier languageIdentifier = LanguageIdentification.getClient();
        languageIdentifier.identifyLanguage(message)
                .addOnSuccessListener(languageCode -> {
                    if (languageCode.equals("und")) {
                        Log.i(TAG, "Can't identify language");
                    } else {
                        Log.i(TAG, "Language: " + languageCode);
                    }
                    
                    // First try to get a response using Dialogflow
                    dialogflowService.sendQuery(message, new DialogflowService.DialogflowCallback() {
                        @Override
                        public void onResult(String response) {
                            // Add bot response to chat
                            addBotMessage(response);
                        }
                        
                        @Override
                        public void onError(String error) {
                            Log.e(TAG, "Dialogflow error: " + error);
                            
                            // Fall back to AI model if Dialogflow fails
                            processWithAIModel(message);
                        }
                    });
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Language identification failed: " + e.getMessage());
                    
                    // Process with AI model if language identification fails
                    processWithAIModel(message);
                });
    }
    
    /**
     * Process a message using the AI model
     * @param message Message to process
     */
    private void processWithAIModel(String message) {
        // Determine if the message is about ALS or neuropathy
        String lowerMessage = message.toLowerCase(Locale.getDefault());
        int modelType;
        
        if (isAboutALS(lowerMessage)) {
            modelType = MedicalAIModel.MODEL_ALS;
        } else if (isAboutNeuropathy(lowerMessage)) {
            modelType = MedicalAIModel.MODEL_NEUROPATHY;
        } else {
            // If we can't determine, default to neuropathy
            modelType = MedicalAIModel.MODEL_NEUROPATHY;
        }
        
        // Get response from the AI model
        String response = medicalAIModel.getResponse(lowerMessage, modelType);
        
        // Add bot response to chat
        addBotMessage(response);
    }
    
    private boolean isGreeting(String message) {
        String[] greetings = {"hello", "hi", "hey", "greetings", "good morning", "good afternoon", "good evening", "bonjour", "salut"};
        for (String greeting : greetings) {
            if (message.contains(greeting)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isAboutALS(String message) {
        String[] alsKeywords = {
            "als", "amyotrophic lateral sclerosis", "motor neuron", "lou gehrig", 
            "muscle weakness", "muscle atrophy", "fasciculations", "bulbar", 
            "upper motor neuron", "lower motor neuron", "familial als", "sporadic als"
        };
        
        for (String keyword : alsKeywords) {
            if (message.contains(keyword)) {
                return true;
            }
        }
        
        return false;
    }
    
    private boolean isAboutNeuropathy(String message) {
        String[] neuropathyKeywords = {
            "neuropathy", "diabetic neuropathy", "peripheral neuropathy", "nerve damage", 
            "nerve pain", "tingling", "numbness", "burning sensation", "pins and needles", 
            "diabetic nerve", "foot pain", "hand pain", "glucose", "diabetes", "diabetic"
        };
        
        for (String keyword : neuropathyKeywords) {
            if (message.contains(keyword)) {
                return true;
            }
        }
        
        return false;
    }
    
    private void addUserMessage(String message) {
        chatMessages.add(new ChatMessage(message, true));
        chatAdapter.notifyItemInserted(chatMessages.size() - 1);
        chatAdapter.notifyDataSetChanged();
        scrollToBottom();
        saveMessageToHistory(message, false);
    }
    
    private void addBotMessage(String message) {
        chatMessages.add(new ChatMessage(message, false));
        chatAdapter.notifyItemInserted(chatMessages.size() - 1);
        chatAdapter.notifyDataSetChanged();
        scrollToBottom();
        saveMessageToHistory(message, true);
    }
    
    private void scrollToBottom() {
        // Utilisation de postDelayed pour s'assurer que le défilement se produit après le rendu complet
        chatRecyclerView.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (chatMessages.size() > 0) {
                    chatRecyclerView.smoothScrollToPosition(chatMessages.size() - 1);
                }
            }
        }, 100); // Délai court pour s'assurer que la vue est complètement mise à jour
    }
    
    private void addBotMessageWithImage(String message, int imageResourceId) {
        chatMessages.add(new ChatMessage(message, imageResourceId));
        chatAdapter.notifyItemInserted(chatMessages.size() - 1);
        chatAdapter.notifyDataSetChanged(); // Assure que l'adaptateur est bien mis à jour
        scrollToBottom();
    }
    
    private void saveMessageToHistory(String message, boolean isBot) {
        SharedPreferences prefs = requireContext().getSharedPreferences(PREFS_HISTORY, Context.MODE_PRIVATE);
        String historyJson = prefs.getString(KEY_HISTORY, "[]");
        try {
            JSONArray array = new JSONArray(historyJson);
            JSONObject obj = new JSONObject();
            obj.put("message", message);
            obj.put("isBot", isBot);
            array.put(obj);
            // Limite à 50 derniers messages
            if (array.length() > MAX_HISTORY) {
                JSONArray newArray = new JSONArray();
                for (int i = array.length() - MAX_HISTORY; i < array.length(); i++) {
                    newArray.put(array.getJSONObject(i));
                }
                array = newArray;
            }
            prefs.edit().putString(KEY_HISTORY, array.toString()).apply();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        
        // Clean up resources
        if (medicalAIModel != null) {
            medicalAIModel.close();
        }
        
        if (dialogflowService != null) {
            dialogflowService.close();
        }
    }
}
